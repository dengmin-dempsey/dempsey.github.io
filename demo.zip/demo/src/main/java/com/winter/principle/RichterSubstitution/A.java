package com.winter.principle.RichterSubstitution;


public class A {

    public int func1(int a, int b){
        return a-b;
    }
}
