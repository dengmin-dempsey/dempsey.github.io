package com.winter.principle.dimitt;


public class SubEmployee {

    private String id;

    public void setId(String id){
        this.id = id;
    }

    public String getId(){
        return id;
    }
}
