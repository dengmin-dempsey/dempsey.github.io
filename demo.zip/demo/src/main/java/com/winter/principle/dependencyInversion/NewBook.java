package com.winter.principle.dependencyInversion;


import com.winter.principle.dependencyInversion.inteface.IReader;

public class NewBook implements IReader {

    public String getContent(){
        return "很久很久以前有一个阿拉伯的故事……";
    }
}
