package com.winter.principle.dependencyInversion;



public class Book {

    public String getContent(){
        return "很久很久以前有一个阿拉伯的故事……";
    }
}
