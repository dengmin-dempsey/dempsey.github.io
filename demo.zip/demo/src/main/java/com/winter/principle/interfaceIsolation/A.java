package com.winter.principle.interfaceIsolation;




public class A {

    public void depend1(InDemo i){
        i.method1();
    }
    public void depend2(InDemo i){
        i.method2();
    }
    public void depend3(InDemo i){
        i.method3();
    }
}
