package com.winter.principle.dependencyInversion.inteface;

public interface IReader {

    public String getContent();

}
