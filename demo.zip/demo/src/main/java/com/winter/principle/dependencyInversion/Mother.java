package com.winter.principle.dependencyInversion;


public class Mother {

    public void narrate(Book book){
        System.out.println("妈妈开始讲故事");
        System.out.println(book.getContent());

    }

}
