package com.winter.principle.dimitt;


public class Client {

    public static void main(String[] args){
        /*CompanyManager e = new CompanyManager();
        e.printAllEmployee(new SubCompanyManager());*/

        NewSubCompanyManager newSubCompanyManager = new NewSubCompanyManager();
        NewCompanyManager newCompanyManager = new NewCompanyManager();
        newCompanyManager.printAllEmployee(newSubCompanyManager);
    }
}
