package com.winter.principle.SingleAccusation;


public class Terrestrial {


    public void breathe(String animal){
        System.out.println(animal+"呼吸空气");
    }

}
