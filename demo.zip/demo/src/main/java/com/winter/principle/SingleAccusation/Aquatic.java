package com.winter.principle.SingleAccusation;


public class Aquatic {


    public void breathe(String animal){
        System.out.println(animal+"呼吸水");
    }
}
