package com.winter.principle.interfaceIsolation;

public interface InDemo {

    public void method1();
    public void method2();
    public void method3();
    public void method4();
    public void method5();
}
