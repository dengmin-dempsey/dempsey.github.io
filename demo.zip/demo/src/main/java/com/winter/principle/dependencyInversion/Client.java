package com.winter.principle.dependencyInversion;


public class Client {

  /*  public static void main(String[] args){
        Mother mother = new Mother();
        mother.narrate(new Book());
    }*/

    public static void main(String[] args){
        NewMother mother = new NewMother();
        mother.narrate(new NewBook());
        mother.narrate(new Newspaper());
    }
}
