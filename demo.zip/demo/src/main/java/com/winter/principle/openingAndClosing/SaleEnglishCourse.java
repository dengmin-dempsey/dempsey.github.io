package com.winter.principle.openingAndClosing;


/**
 * 定义课程拓展类
 */
public class SaleEnglishCourse extends EnglishCourse{

    public SaleEnglishCourse(String name, Double price, String teacher) {
        super(name, price, teacher);
    }

    @Override
    public Double getPrice() {
        return super.getPrice() * 0.85;
    }
}
