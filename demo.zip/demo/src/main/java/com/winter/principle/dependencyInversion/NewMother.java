package com.winter.principle.dependencyInversion;


import com.winter.principle.dependencyInversion.inteface.IReader;

public class NewMother {

    public void narrate(IReader reader){
        System.out.println("妈妈开始讲故事");
        System.out.println(reader.getContent());
    }
}
