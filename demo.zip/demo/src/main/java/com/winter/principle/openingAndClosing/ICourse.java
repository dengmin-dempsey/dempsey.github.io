package com.winter.principle.openingAndClosing;

/**
 * 定义课程接口
 */
public interface ICourse {

    String getName();  // 获取课程名称
    Double getPrice(); // 获取课程价格
    String getTeacher(); // 获取课程教师
}
