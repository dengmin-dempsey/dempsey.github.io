package com.winter.principle.openingAndClosing;



public class Client {

    public static void main(String[] args) {
        ICourse course = new EnglishCourse("小学英语", 199D, "张老师");
        System.out.println(
                "课程名字:"+course.getName() + " " +
                        "课程价格:"+course.getPrice() + " " +
                        "课程教师:"+course.getTeacher());

    ICourse course2 = new SaleEnglishCourse("小学英语", 199D, "张老师");
        System.out.println(
                "课程名字:"+course2.getName() + " " +
                "折后课程价格:"+course2.getPrice() + " " +
                "课程教师:"+course2.getTeacher());

}
}
