package com.winter.principle.openingAndClosing;


/**
 * 英语课程接口实现
 */
public class EnglishCourse implements ICourse{

    private String name;
    private Double price;
    private String teacher;

    public EnglishCourse(String name, Double price, String teacher) {
        this.name = name;
        this.price = price;
        this.teacher = teacher;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public Double getPrice() {
        return price;
    }

    @Override
    public String getTeacher() {
        return teacher;
    }


}
