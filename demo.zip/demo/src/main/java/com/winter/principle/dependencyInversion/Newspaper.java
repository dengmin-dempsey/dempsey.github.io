package com.winter.principle.dependencyInversion;


import com.winter.principle.dependencyInversion.inteface.IReader;

public class Newspaper implements IReader{

    public String getContent(){
        return "林书豪38+7领导尼克斯击败湖人……";
    }
}
