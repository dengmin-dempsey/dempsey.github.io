package com.winter.designPattern.interpreter.interpreterDemo1;


public class PlayContext {
    //演奏文本
    private String text;

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
