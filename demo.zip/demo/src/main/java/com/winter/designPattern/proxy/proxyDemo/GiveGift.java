package com.winter.designPattern.proxy.proxyDemo;

public interface GiveGift {
    void giveDolls();

    void giveFlowers();

    void giveChocolate();
}
