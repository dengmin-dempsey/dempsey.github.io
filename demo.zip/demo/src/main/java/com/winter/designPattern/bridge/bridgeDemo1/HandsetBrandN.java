package com.winter.designPattern.bridge.bridgeDemo1;

public class HandsetBrandN extends HandsetBrand {
    @Override
    public void run() {
        soft.run();
    }
}
