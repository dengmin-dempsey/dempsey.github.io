package com.winter.designPattern.bridge.bridgeDemo1;

public abstract class HandsetSoft {
    public abstract void run();
}
