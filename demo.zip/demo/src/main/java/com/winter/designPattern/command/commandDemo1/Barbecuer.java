package com.winter.designPattern.command.commandDemo1;

public class Barbecuer {
    //烤羊肉
    public void bakeMutton(){
        System.out.println("烤羊肉串");
    }

    //烤鸡翅
    public void bakeChickenWing(){
        System.out.println("烤鸡翅");
    }
}
