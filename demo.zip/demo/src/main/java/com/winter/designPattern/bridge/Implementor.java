package com.winter.designPattern.bridge;

public abstract class Implementor {
    public abstract void operation();
}
