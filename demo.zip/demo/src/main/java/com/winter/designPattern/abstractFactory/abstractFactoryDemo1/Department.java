package com.winter.designPattern.abstractFactory.abstractFactoryDemo1;

public class Department {
}
