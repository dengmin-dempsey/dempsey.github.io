package com.winter.designPattern.bridge;

public class RefineAbstraction extends Abstarction {
    @Override
    public void operation() {
        super.operation();
    }
}
