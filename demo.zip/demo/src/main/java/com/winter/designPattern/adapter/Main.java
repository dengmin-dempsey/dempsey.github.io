package com.winter.designPattern.adapter;

public class Main {
    public static void main(String[] args){
        Target target = new Adapter();
        target.request();
    }
}
