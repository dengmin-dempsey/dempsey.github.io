package com.winter.designPattern.bridge.bridgeDemo1;

public class HandsetBrandM extends HandsetBrand {
    @Override
    public void run() {
        soft.run();
    }
}
