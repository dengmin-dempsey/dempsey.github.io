package com.winter.designPattern.mediator.mediatorDemo1;

/**
 * 联合国机构类
 */
public abstract class UnitedNations {
    //声明
    public abstract void declare(String message, Country colleague);
}
