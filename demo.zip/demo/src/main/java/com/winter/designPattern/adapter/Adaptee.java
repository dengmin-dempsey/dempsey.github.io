package com.winter.designPattern.adapter;

/**
 * 需要适配的类
 */
public class Adaptee {
    public void specificRequest(){
        System.out.println("特殊请求!");
    }
}
