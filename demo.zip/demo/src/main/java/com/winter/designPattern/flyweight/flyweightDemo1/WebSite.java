package com.winter.designPattern.flyweight.flyweightDemo1;

/**
 * 网站抽象类
 */
public abstract class WebSite {
    public abstract void use();
}
