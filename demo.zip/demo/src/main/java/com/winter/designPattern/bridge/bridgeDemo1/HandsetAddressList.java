package com.winter.designPattern.bridge.bridgeDemo1;

public class HandsetAddressList extends HandsetSoft {
    @Override
    public void run() {
        System.out.println("运行手机通讯录");
    }
}
