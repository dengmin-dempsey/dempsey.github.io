package com.winter.designPattern.state.stateDemo2;



public abstract class State {
    public abstract void WriteProgram(Work w);


}
