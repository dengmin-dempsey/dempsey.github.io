package com.winter.designPattern.factoryMethod.factoryMethodDemo2;

/**
 * 雷锋工厂
 */
public interface IFactory {
    LeiFeng createLeiFeng();
}


